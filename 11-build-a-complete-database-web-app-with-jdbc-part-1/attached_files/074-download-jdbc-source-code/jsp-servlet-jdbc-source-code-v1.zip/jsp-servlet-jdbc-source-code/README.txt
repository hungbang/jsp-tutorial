JSP and Servlets for Beginners -- JDBC Database Example
=======================================================

This directory contains the source code and SQL scripts for the JSP/Servlet JDBC example.

I created two directories for the application.

web-student-tracker-starter-files: 
- These are some starter files if you want to start from scratch. 
- You can follow along with me in the videos.

web-student-tracker-solution: 
- This is the final solution, includes all code
- You can review the code as I go through the videos or just deploy it



package com.luv2code.jsp;

public class FunUtils {

	public static String makeItLower(String data) {
		return data.toLowerCase();
	}
	
}
